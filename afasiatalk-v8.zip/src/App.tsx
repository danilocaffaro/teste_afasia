import React, { useEffect, useMemo, useRef, useState } from "react";

/**
 * AfasiaTalk — MVP v8 (PT-BR)
 * Always-Online Neural • Setup Profundo (50–80 intenções) c/ Slider • ASR Biasing
 * Aprendizado Contínuo • Multi-Palavras Curinga • Sinônimos (ex.: “namorada” ≃ “meu amor”)
 * Parceiro (micro-lições) • Desafio Diário • Métricas + Export CSV/Imprimir
 * Simulação de Personas
 *
 * Endpoints esperados:
 *  POST {base}/api/asr/stream
 *  POST {base}/api/nlu/parse
 *  POST {base}/api/translate
 *  POST {base}/api/personalize
 *  POST {base}/api/personalize/synonyms
 *  (header opcional: x-provider = "auto"|"openai"|"google"|"anthropic"|"azure"|"mix")
 */

// ========================== Utilitários ==========================
function classNames(...xs: Array<string | false | null | undefined>) { return xs.filter(Boolean).join(" "); }
function speak(text: string) { try { const s = window.speechSynthesis; if (!s) return; const u = new SpeechSynthesisUtterance(text); u.lang = "pt-BR"; s.cancel(); s.speak(u);} catch {} }
function tokenizePT(s: string) { return s.toLowerCase().normalize("NFD").replace(/[^\p{L}\p{N}\s]/gu, " ").split(/\s+/).filter(Boolean); }
const STOP = new Set(["o","a","os","as","um","uma","de","do","da","no","na","em","pro","pra","para","por","que","e"]);
const MODS = new Set(["grande","pequeno","pequena","médio","media","média","alto","baixa","baixinho","altinho","vermelho","vermelha","azul","preto","preta","branco","branca","verde","amarelo","amarela","rosa","roxo","roxa","cinza","muito","pouco","forte","fraco","quente","fria","gelada","rápido","devagar","doce","salgado","sem","com","mais","menos"]);
function extractBaseAndQual(s: string){ const t = tokenizePT(s); const q:string[]=[]; const c:string[]=[]; for(const x of t){ if(STOP.has(x)) continue; if(MODS.has(x)){ q.push(x); continue;} c.push(x);} const base=c[0]||t[0]||""; return { base, qualifiers:q, qualifierKey:q.sort().join("+")}; }
function uniq<T>(arr:T[]):T[]{ return Array.from(new Set(arr)); }

// ========================== Cliente API ==========================
async function api(base: string, path: string, body: any, provider: string, timeoutMs=10000): Promise<any|null>{
  const ctrl = new AbortController(); const to = setTimeout(()=>ctrl.abort(), timeoutMs);
  try{ const resp = await fetch(base+path,{method:"POST", headers:{"Content-Type":"application/json", ...(provider?{"x-provider":provider}:{})}, body: JSON.stringify(body), signal: ctrl.signal}); clearTimeout(to); if(!resp.ok) return null; return await resp.json(); }catch{ clearTimeout(to); return null; }
}
const nluParse = (base:string,prov:string,text:string,context:any)=> api(base,"/api/nlu/parse",{text,context},prov);
const translateIntent = (base:string,prov:string,intent:any,slots:any,lex:any)=> api(base,"/api/translate",{intent,slots,personalLexicon:lex},prov);
const personalizeLexicon = (base:string,prov:string,pairs:any[])=> api(base,"/api/personalize",{pairs},prov);
const personalizeSynonyms = (base:string,prov:string,syn:any)=> api(base,"/api/personalize/synonyms",{synonyms:syn},prov);

// ========================== Banco de Intenções (≈64 alvos) ==========================
const INTENT_BANK: {cat:string; items:{ key:string; phrase:string; }[]}[] = [
  { cat:"Básico", items:[
    {key:"sim", phrase:"Sim."},{key:"não", phrase:"Não."},{key:"ajuda", phrase:"Preciso de ajuda, por favor."},{key:"banheiro", phrase:"Preciso ir ao banheiro."},{key:"água", phrase:"Quero água, por favor."},{key:"comida", phrase:"Estou com fome, quero comer."},{key:"copo", phrase:"Quero um copo, por favor."}
  ]},
  { cat:"Saúde", items:[
    {key:"dor", phrase:"Estou com dor."},{key:"dor_cabeça", phrase:"Estou com dor de cabeça."},{key:"tontura", phrase:"Estou tonto(a)."},{key:"remédio", phrase:"Preciso do meu remédio."},{key:"cansaço", phrase:"Estou cansado(a)."},{key:"frio", phrase:"Estou com frio."},{key:"calor", phrase:"Estou com calor."}
  ]},
  { cat:"Família", items:[
    {key:"mãe", phrase:"Quero falar com a minha mãe."},{key:"pai", phrase:"Quero falar com o meu pai."},{key:"esposa", phrase:"Quero falar com a minha esposa."},{key:"esposo", phrase:"Quero falar com o meu esposo."},{key:"filho", phrase:"Quero falar com meu filho."},{key:"filha", phrase:"Quero falar com minha filha."},{key:"namorada", phrase:"Quero falar com minha namorada."}
  ]},
  { cat:"Rotina/Lazer", items:[
    {key:"telefone", phrase:"Quero o telefone, por favor."},{key:"tv", phrase:"Quero assistir TV."},{key:"música", phrase:"Quero ouvir música."},{key:"banho", phrase:"Quero tomar banho."},{key:"passear", phrase:"Quero sair para passear."},{key:"cozinhar", phrase:"Quero cozinhar algo."},{key:"ler", phrase:"Quero ler um livro."}
  ]},
  { cat:"Social/Opinião", items:[
    {key:"op_filme", phrase:"Quero comentar sobre um filme."},{key:"op_música", phrase:"Quero falar sobre uma música."},{key:"historia_dia", phrase:"Quero contar como foi meu dia."},{key:"elogio", phrase:"Quero fazer um elogio."},{key:"agradecer", phrase:"Quero agradecer."},{key:"desculpar", phrase:"Quero pedir desculpas."}
  ]},
  { cat:"Planejamento", items:[
    {key:"planejar_fds", phrase:"Quero planejar o fim de semana."},{key:"compras", phrase:"Quero fazer compras."},{key:"consulta", phrase:"Quero marcar uma consulta."},{key:"visita", phrase:"Quero combinar uma visita."},{key:"viagem", phrase:"Quero planejar uma viagem."},{key:"agenda", phrase:"Quero organizar minha agenda."}
  ]},
  { cat:"Trabalho/Estudo", items:[
    {key:"reuniao", phrase:"Quero marcar uma reunião."},{key:"email", phrase:"Quero enviar um e-mail."},{key:"tarefa", phrase:"Quero revisar minhas tarefas."},{key:"aula", phrase:"Quero falar sobre a aula."},{key:"projeto", phrase:"Quero discutir um projeto."}
  ]},
  { cat:"Deslocamento/Lugares", items:[
    {key:"onibus", phrase:"Quero pegar um ônibus."},{key:"carro", phrase:"Quero chamar um carro."},{key:"farmacia", phrase:"Quero ir à farmácia."},{key:"mercado", phrase:"Quero ir ao mercado."},{key:"parque", phrase:"Quero ir ao parque."},{key:"restaurante", phrase:"Quero ir ao restaurante."}
  ]}
];
const CORE = INTENT_BANK.flatMap(x=>x.items);

// ========================== Tipos/Estado ==========================
type Mapping = { target: string; userForms: string[]; examples?: string[] };
interface HistoryItem { input:string; output:string; confirmed:boolean; ts:number; intentGuess?:string }
interface AppState {
  ai: { baseUrl: string; provider: string; asrBias: boolean };
  mappings: Mapping[];
  synonyms: Record<string,string[]>; // ex.: { "namorada": ["meu amor","minha mina"] }
  history: HistoryItem[];
  tts: boolean;
  perf: Record<string, { seen:number; tp1:number; corrections:number }>;
  dailyGoal: number; dailyProgress: number; streak: number;
  setup: { active:boolean; catIdx:number; queue:number[]; idx:number; done:number; depth:number; summary?: any };
}

const INITIAL: AppState = {
  ai:{ baseUrl:"", provider:"auto", asrBias:true },
  mappings:[], synonyms:{}, history:[], tts:true,
  perf:{}, dailyGoal:5, dailyProgress:0, streak:0,
  setup:{ active:false, catIdx:0, queue:[], idx:0, done:0, depth:64, summary: undefined },
};

// ========================== Helpers de análise (curinga / variantes / cobertura) ==========================
function computeSurrogates(mappings: Mapping[]){
  const map: Record<string, Set<string>> = {}; // base -> targets
  const variants: Record<string, Record<string, Set<string>>> = {}; // base -> qKey -> targets
  const formsByTarget: Record<string, string[]> = {};
  for(const m of mappings){
    for(const f of m.userForms){
      const { base, qualifierKey } = extractBaseAndQual(f);
      const b = base || f;
      if(!map[b]) map[b] = new Set();
      map[b].add(m.target);
      if(!variants[b]) variants[b] = {};
      const qk = qualifierKey || "(sem-qualificador)";
      if(!variants[b][qk]) variants[b][qk] = new Set();
      variants[b][qk].add(m.target);
      formsByTarget[m.target] = uniq([...(formsByTarget[m.target]||[]), f]);
    }
  }
  const surrogateCandidates = Object.entries(map).map(([form, set])=>({ form, targets: Array.from(set), count: set.size })).sort((a,b)=>b.count-a.count);
  const variantCandidates: { base:string; qualifierKey:string; qualifiers:string[]; targets:string[]; count:number }[] = [];
  for(const [base, qmap] of Object.entries(variants)){
    for(const [qk,set] of Object.entries(qmap)){
      if(qk!=="(sem-qualificador)") variantCandidates.push({ base, qualifierKey: qk, qualifiers: qk.split("+"), targets: Array.from(set), count: (set as any).size||Array.from(set).length });
    }
  }
  variantCandidates.sort((a,b)=>b.count-a.count);
  return { surrogateCandidates, variantCandidates, formsByTarget };
}

function computeCoverageSummary(queue:number[], mappings: Mapping[]){
  const targetSet = new Set(queue.map(i=>CORE[i]?.key).filter(Boolean));
  const covered = new Set<string>();
  for(const m of mappings){ if(targetSet.has(m.target) && m.userForms.length>0) covered.add(m.target); }
  const coveragePct = targetSet.size? Math.round((covered.size / targetSet.size)*100) : 0;
  const level = coveragePct < 40 ? "básico" : coveragePct < 75 ? "intermediário" : "avançado";
  const { surrogateCandidates, variantCandidates } = computeSurrogates(mappings);
  return { coveragePct, level, covered: Array.from(covered), total: targetSet.size, surrogateCandidates, variantCandidates };
}

// ========================== App ==========================
export default function App(){
  const [tab,setTab]=useState<"setup"|"talk"|"challenge"|"partner"|"metrics"|"simulate">("setup");
  const [s,setS]=useState<AppState>(INITIAL);
  const [input,setInput]=useState("");
  const [out,setOut]=useState("");
  const [alts,setAlts]=useState<string[]>([]);

  const biasWords = useMemo(()=> uniq(s.mappings.flatMap(m=>m.userForms.concat([m.target]))), [s.mappings]);

  function resetAll(){ if(!confirm("Zerar dados locais?")) return; setS(INITIAL); setInput(""); setOut(""); setAlts([]); }

  // -------- Setup Profundo --------
  function startSetup(catIdx=0){
    const indices = CORE.map((_,i)=>i);
    indices.sort(()=>Math.random()-0.5);
    const pick = indices.slice(0, Math.min(s.setup.depth, CORE.length));
    setS(prev=>({...prev, setup:{ active:true, catIdx, queue:pick, idx:0, done:0, depth: prev.setup.depth, summary: undefined }}));
    setInput(""); setOut(""); setAlts([]);
  }
  const currentIdx = s.setup.queue[s.setup.idx] ?? 0;
  const currentItem = CORE[currentIdx] ?? CORE[0];

  async function saveSetupUtterance(){
    const said = input.trim(); if(!said) return;
    const { qualifiers } = extractBaseAndQual(said);
    // atualizar mapeamento local
    setS(prev=>{ const m=[...prev.mappings]; const i=m.findIndex(x=>x.target===currentItem.key); if(i<0){ m.push({target:currentItem.key, userForms:[said]}); } else { if(!m[i].userForms.includes(said)) m[i].userForms=[...m[i].userForms, said]; }
      const next={ ...prev, mappings:m, setup:{...prev.setup, idx: prev.setup.idx+1, done: prev.setup.done+1 } } as AppState;
      if(next.setup.idx >= next.setup.queue.length){
        next.setup.active = false;
        next.setup.summary = computeCoverageSummary(next.setup.queue, next.mappings);
      }
      return next;
    });
    // enviar personalização
    if(s.ai.baseUrl){ await personalizeLexicon(s.ai.baseUrl, s.ai.provider, [{ inputText: said, targetKey: currentItem.key, qualifiers }]); }
    setInput("");
  }

  // -------- Sinônimos (equivalências) --------
  const [synA, setSynA] = useState("");
  const [synB, setSynB] = useState("");
  function addSynonymPair(){
    const a = synA.trim().toLowerCase(); const b = synB.trim().toLowerCase(); if(!a||!b) return;
    setS(prev=>{ const syn = { ...prev.synonyms } as Record<string,string[]>; syn[a] = uniq([...(syn[a]||[]), b]); syn[b] = uniq([...(syn[b]||[]), a]); return { ...prev, synonyms: syn }; });
    setSynA(""); setSynB("");
  }
  async function pushSynonyms(){ if(!s.ai.baseUrl) return; await personalizeSynonyms(s.ai.baseUrl, s.ai.provider, s.synonyms); }

  // -------- Conversa/Tradução --------
  async function translateNow(text:string){
    if(!s.ai.baseUrl){ alert("Configure a API base (URL) no topo."); return; }
    const surrogate = computeSurrogates(s.mappings);
    const ctx = { time: Date.now(), personalLexicon: s.mappings, synonyms: s.synonyms, surrogateMap: surrogate.surrogateCandidates, hintBias: s.ai.asrBias? biasWords : [] };
    const nlu = await nluParse(s.ai.baseUrl, s.ai.provider, text, ctx);
    if(!nlu || !nlu.intent){ alert("Falha no NLU neural."); return; }
    const tr = await translateIntent(s.ai.baseUrl, s.ai.provider, nlu.intent, nlu.slots, s.mappings);
    if(!tr || !tr.phrase){ alert("Falha na tradução neural."); return; }
    const phrase = tr.phrase as string; const alternatives = (tr.alternatives||[]) as string[];
    setOut(phrase); setAlts(alternatives);
    setS(prev=>{
      const perf = { ...prev.perf };
      const p = perf[nlu.intent] || { seen:0, tp1:0, corrections:0 };
      p.seen += 1; perf[nlu.intent] = p;
      return { ...prev, history: [{ input:text, output:phrase, confirmed:false, ts:Date.now(), intentGuess:nlu.intent }, ...prev.history].slice(0,100), dailyProgress: prev.dailyProgress+1, perf };
    });
    if(phrase && s.tts) speak(phrase);
  }

  function confirmOutput(ok:boolean, corrected?:string){
    setS(prev=>{
      const [last,...rest]=prev.history; const updated = last? [{...last, output: corrected||last.output, confirmed: ok}, ...rest] : prev.history;
      const perf = { ...prev.perf };
      if(last?.intentGuess){ const p = perf[last.intentGuess] || {seen:0,tp1:0,corrections:0}; if(ok) p.tp1 += 1; else p.corrections += 1; perf[last.intentGuess]=p; }
      return { ...prev, history: updated, perf };
    });
    speak(corrected || out);
  }

  // -------- Parceiro de Conversa (micro-lições) --------
  const PARTNER_TIPS = [
    { id:"confirmar", title:"Confirmar, não corrigir", body:"Repetir a ideia do paciente e perguntar se é isso mesmo." },
    { id:"opcoes", title:"Oferecer 2 opções", body:"Apresentar duas alternativas com texto/ícone para facilitar a escolha." },
    { id:"qualificador", title:"Pedir qualificador", body:"Perguntar tamanho/cor/lugar para reduzir ambiguidade de palavra-curinga." },
    { id:"tempo", title:"Dar tempo", body:"Esperar alguns segundos antes de intervir; reduzir pressão." },
  ];

  // -------- Métricas e fraquezas --------
  const weakIntents = useMemo(()=>{
    const arr = Object.entries(s.perf).map(([k,v])=>({k, rate: v.seen ? v.tp1/v.seen : 0, seen:v.seen})).filter(x=>x.seen>=2).sort((a,b)=>a.rate-b.rate).slice(0,6).map(x=>x.k);
    return arr.length?arr:CORE.slice(0,6).map(x=>x.key);
  },[s.perf]);

  // -------- Export CSV / Imprimir --------
  function exportCSV(){
    const rows = [["ts","input","output","confirmed","intent"], ...s.history.map(h=>[new Date(h.ts).toISOString(), h.input, h.output, String(h.confirmed), h.intentGuess||""] )];
    const csv = rows.map(r=> r.map(x=>`"${String(x).replace(/"/g,'""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = `afasiaTalk_${Date.now()}.csv`; a.click(); URL.revokeObjectURL(url);
  }
  function printReport(){ window.print(); }

  // -------- Simulação (usa PERSONAS locais) --------
  const PERSONAS = [
    { nome:"Marina", cobertura:30, comportamento:"anomia grave + curinga 'coisa'", acuraciaAntes:40, acuraciaDepois:65,
      conversa:["ontem fui coisa grande e vi passarinho","coisa mãe feliz aniversário","quero ir coisa praia domingo","coisa bom filme ontem","notícia coisa assustador"] },
    { nome:"João", cobertura:50, comportamento:"parafasia semântica + curinga 'negócio'", acuraciaAntes:70, acuraciaDepois:85,
      conversa:["fui no negócio de ver peça","liguei pro negócio que toca","viagem pro negócio com montanha","esposa fez negócio delicioso","notícia negócio importante"] },
    { nome:"Lúcia", cobertura:80, comportamento:"anomia leve, autocorreção", acuraciaAntes:90, acuraciaDepois:96,
      conversa:["marcar jantar com meus pais","assisti a um documentário sobre arte","visitar o museu novo","palestra sobre tecnologia","história engraçada no trabalho"] },
  ];
  function traducaoSimulada(nome:string, frase:string){ if(nome==="Marina") return frase.replace(/coisa/g,"[item]"); if(nome==="João") return frase.replace(/negócio/g,"[objeto]"); return frase; }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <header className="sticky top-0 bg-white border-b">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="text-xl font-bold">AfasiaTalk <span className="text-sm text-gray-500">— MVP v8 (Neural)</span></div>
          <div className="flex items-center gap-2">
            <select value={s.ai.provider} onChange={e=>setS({...s, ai:{...s.ai, provider:e.target.value}})} className="text-sm px-2 py-1 border rounded-lg">
              <option value="auto">auto</option><option value="openai">OpenAI</option><option value="google">Google</option><option value="anthropic">Anthropic</option><option value="azure">Azure</option><option value="mix">mix</option>
            </select>
            <input value={s.ai.baseUrl} onChange={e=>setS({...s, ai:{...s.ai, baseUrl:e.target.value}})} placeholder="API base (https://...)" className="text-sm px-2 py-1 border rounded-lg w-56"/>
            <label className="text-sm flex items-center gap-2"><input type="checkbox" checked={s.ai.asrBias} onChange={e=>setS({...s, ai:{...s.ai, asrBias:e.target.checked})}/> ASR bias</label>
            <label className="text-sm flex items-center gap-2"><input type="checkbox" checked={s.tts} onChange={e=>setS({...s, tts:e.target.checked})}/> Voz</label>
            <button onClick={resetAll} className="text-sm px-3 py-1 rounded-full bg-gray-100 hover:bg-gray-200">Zerar</button>
          </div>
        </div>
        <nav className="max-w-4xl mx-auto px-4 pb-2 grid grid-cols-6 gap-2">
          {(["setup","talk","challenge","partner","metrics","simulate"] as const).map(id=> (
            <button key={id} onClick={()=>setTab(id)} className={classNames("py-2 rounded-xl border text-sm", tab===id?"bg-blue-600 text-white border-blue-600":"bg-white hover:bg-gray-50")}>{{
              "setup":"Setup Profundo", "talk":"Conversar", "challenge":"Desafio", "partner":"Parceiro", "metrics":"Métricas", "simulate":"Simular"
            }[id]}</button>
          ))}
        </nav>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-6">
        {tab==="setup" && (
          <section className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <h2 className="text-lg font-semibold">Setup Profundo — 50–80 intenções</h2>
              <div className="flex items-center gap-3">
                <div className="text-sm flex items-center gap-2">
                  <span>Profundidade:</span>
                  <input type="range" min={16} max={80} step={16} value={s.setup.depth} onChange={(e)=>setS({...s, setup:{...s.setup, depth: parseInt(e.target.value)}})} />
                  <span className="w-10 text-right">{s.setup.depth}</span>
                </div>
                <select className="text-sm border rounded-lg px-2 py-1" value={s.setup.catIdx} onChange={e=>setS({...s, setup:{...s.setup, catIdx: parseInt(e.target.value)}})}>
                  {INTENT_BANK.map((b, i)=>(<option key={i} value={i}>{b.cat}</option>))}
                </select>
                <button onClick={()=>startSetup(s.setup.catIdx)} className="px-3 py-1 rounded-lg bg-indigo-600 text-white">Iniciar/Continuar</button>
              </div>
            </div>

            {s.setup.active ? (
              <div className="p-4 rounded-2xl border bg-white">
                <div className="text-xs text-gray-500">Item {s.setup.idx+1} de {s.setup.queue.length}</div>
                <div className="text-base font-medium">Alvo: {currentItem.key}</div>
                <div className="text-sm text-gray-600">Frase alvo: “{currentItem.phrase}”</div>
                <textarea value={input} onChange={e=>setInput(e.target.value)} placeholder="Como você diria isso? (ex.: 'coisa fria', 'negócio de ver')" className="w-full border rounded-xl p-3 mt-2"/>
                <div className="flex gap-2 mt-2">
                  <button onClick={saveSetupUtterance} className="px-4 py-2 rounded-xl bg-blue-600 text-white">Salvar</button>
                  <button onClick={()=>setInput("")} className="px-3 py-2 rounded-xl bg-gray-100">Limpar</button>
                </div>
                <div className="text-xs text-gray-500 mt-2">Dica SFA/PCA: fale função, categoria, cor/tamanho, ou a primeira letra/som.</div>
              </div>
            ) : (
              <>
                <div className="text-sm text-gray-600">Escolha a profundidade e a categoria e clique em <strong>Iniciar</strong>. O app coleta sinônimos, <strong>múltiplas palavras-curinga</strong> e qualificadores para personalizar a tradução.</div>
                {s.setup.summary && (
                  <div className="p-4 rounded-2xl border bg-emerald-50">
                    <div className="font-medium">Resumo do Setup</div>
                    <div className="text-sm mt-1">Cobertura do conjunto calibrado: <strong>{s.setup.summary.coveragePct}%</strong> • Nível: <strong>{s.setup.summary.level}</strong> • Itens com forma pessoal: <strong>{s.setup.summary.covered.length}</strong> de {s.setup.summary.total}</div>
                    {s.setup.summary.surrogateCandidates?.length>0 && (
                      <div className="text-sm mt-2">
                        <div className="font-semibold">Palavras-curinga detectadas</div>
                        <ul className="list-disc pl-5">
                          {s.setup.summary.surrogateCandidates.filter((x:any)=>x.count>=3).slice(0,6).map((c:any,i:number)=> (
                            <li key={i}>“{c.form}” usado para {c.count} intenções: {c.targets.join(", ")}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                    {s.setup.summary.variantCandidates?.length>0 && (
                      <div className="text-sm mt-2">
                        <div className="font-semibold">Variações qualificadas</div>
                        <ul className="list-disc pl-5">
                          {s.setup.summary.variantCandidates.slice(0,6).map((v:any,i:number)=> (
                            <li key={i}>base “{v.base}” + [{v.qualifiers.join(", ")}] → {v.count} intenções</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}

                <div className="p-4 rounded-2xl border bg-white">
                  <div className="font-medium mb-1">Adicionar sinônimos</div>
                  <div className="flex flex-col sm:flex-row gap-2 items-start sm:items-center">
                    <input value={synA} onChange={e=>setSynA(e.target.value)} placeholder="Ex.: namorada" className="border rounded-lg px-2 py-1 w-full sm:w-56"/>
                    <span className="text-sm text-gray-500">≃</span>
                    <input value={synB} onChange={e=>setSynB(e.target.value)} placeholder="Ex.: meu amor" className="border rounded-lg px-2 py-1 w-full sm:w-56"/>
                    <button onClick={addSynonymPair} className="px-3 py-1 rounded-lg bg-blue-600 text-white">Adicionar</button>
                    <button onClick={pushSynonyms} className="px-3 py-1 rounded-lg bg-indigo-600 text-white">Enviar ao modelo</button>
                  </div>
                  {Object.keys(s.synonyms).length>0 && (
                    <div className="text-xs text-gray-600 mt-2">Sinônimos atuais: {Object.entries(s.synonyms).slice(0,8).map(([k,v])=>`${k} ≃ ${v.slice(0,2).join(' / ')}`).join("; ")} {Object.keys(s.synonyms).length>8?"…":""}</div>
                  )}
                </div>
              </>
            )}
          </section>
        )}

        {tab==="talk" && (
          <section className="space-y-4">
            <h2 className="text-lg font-semibold">Conversa — Tradução Neural com Aprendizado Contínuo</h2>
            <div className="p-4 rounded-2xl border bg-white space-y-2">
              <textarea value={input} onChange={e=>setInput(e.target.value)} placeholder="Fale ou digite…" className="w-full min-h-[80px] border rounded-xl p-3"/>
              <div className="flex items-center gap-2">
                <button onClick={()=>translateNow(input)} className="px-4 py-2 rounded-xl bg-blue-600 text-white">Traduzir</button>
                <button onClick={()=>{setInput(""); setOut(""); setAlts([]);}} className="px-3 py-2 rounded-xl bg-gray-100">Limpar</button>
                <div className="text-xs text-gray-500">Bias ASR ativo: {s.ai.asrBias?"sim":"não"} ({biasWords.length} termos)</div>
              </div>
              <div className="p-3 bg-gray-50 rounded-xl border">
                <div className="text-xs text-gray-500">Sugestão</div>
                <div className="text-lg font-medium">{out || "(sem sugestão)"}</div>
                <div className="mt-2 flex gap-2">
                  <button onClick={()=>confirmOutput(true)} className="px-3 py-2 rounded-xl bg-emerald-600 text-white">✔️ Confirmar</button>
                  <button onClick={()=>confirmOutput(false)} className="px-3 py-2 rounded-xl bg-amber-600 text-white">🔁 Corrigir</button>
                </div>
                {alts.length>0 && (
                  <div className="mt-2">
                    <div className="text-xs text-gray-500 mb-1">Talvez queria dizer:</div>
                    <div className="flex flex-wrap gap-2">{alts.map((a,i)=>(<button key={i} onClick={()=>confirmOutput(true,a)} className="px-3 py-1 rounded-full bg-white border text-sm hover:bg-gray-50">{a}</button>))}</div>
                  </div>
                )}
              </div>
            </div>
          </section>
        )}

        {tab==="challenge" && (
          <section className="space-y-3">
            <h2 className="text-lg font-semibold">Desafio Diário</h2>
            <div className="text-sm text-gray-600">Meta: {s.dailyGoal} • Progresso: {s.dailyProgress} • Série: {s.streak} 🔥</div>
            <div className="p-4 rounded-2xl border bg-white">
              <div className="text-xs text-gray-500 mb-1">Foco em fraquezas detectadas</div>
              <div className="flex flex-wrap gap-2 mb-2">{weakIntents.map(k=> (<span key={k} className="px-2 py-1 rounded-full bg-gray-100 text-xs">{k}</span>))}</div>
              <textarea value={input} onChange={e=>setInput(e.target.value)} placeholder={`Tente falar algo sobre: ${weakIntents.slice(0,3).join(", ")}`} className="w-full border rounded-xl p-3"/>
              <div className="mt-2 flex gap-2">
                <button onClick={()=>translateNow(input)} className="px-4 py-2 rounded-xl bg-purple-600 text-white">Responder</button>
                <button onClick={()=>setInput("")} className="px-3 py-2 rounded-xl bg-gray-100">Pular</button>
              </div>
              <div className="text-xs text-gray-500 mt-2">Conquiste pontos ao acertar de 1ª; o app usa suas confirmações e sinônimos para melhorar.</div>
            </div>
          </section>
        )}

        {tab==="partner" && (
          <section className="space-y-3">
            <h2 className="text-lg font-semibold">Parceiro de Conversa — micro-lições (≈90s)</h2>
            <div className="grid sm:grid-cols-2 gap-3">
              {PARTNER_TIPS.map(t=> (
                <div key={t.id} className="p-3 rounded-2xl border bg-white">
                  <div className="font-medium">{t.title}</div>
                  <div className="text-sm text-gray-700">{t.body}</div>
                  <div className="mt-2 text-xs text-gray-500">Ex.: ofereça 2 opções com imagens; peça um qualificador como cor/tamanho/lugar.</div>
                </div>
              ))}
            </div>
            <div className="p-3 rounded-2xl border bg-emerald-50 text-sm">Dica: use “Confirmar” quando acertarmos de 1ª; isso acelera o aprendizado.</div>
          </section>
        )}

        {tab==="metrics" && (
          <section className="space-y-4">
            <h2 className="text-lg font-semibold">Métricas (locais — exemplo)</h2>
            <div className="grid sm:grid-cols-2 gap-3">
              <div className="p-3 rounded-2xl border bg-white text-sm flex items-center justify-between"><span>Traduções (sessão)</span><strong>{s.history.length}</strong></div>
              <div className="p-3 rounded-2xl border bg-white text-sm flex items-center justify-between"><span>Progresso diário</span><strong>{s.dailyProgress}/{s.dailyGoal}</strong></div>
            </div>

            {s.setup.summary && (
              <div className="p-3 rounded-2xl border bg-white">
                <div className="font-medium mb-1">Resumo do Setup</div>
                <div className="text-sm">Cobertura: <strong>{s.setup.summary.coveragePct}%</strong> • Nível: <strong>{s.setup.summary.level}</strong> • Itens: {s.setup.summary.covered.length}/{s.setup.summary.total}</div>
                <div className="text-sm mt-2">Top palavras-curinga:</div>
                <ul className="list-disc pl-5 text-sm">
                  {s.setup.summary.surrogateCandidates.filter((x:any)=>x.count>=3).slice(0,6).map((c:any,i:number)=> (<li key={i}>“{c.form}” → {c.targets.join(", ")}</li>))}
                </ul>
              </div>
            )}

            <div className="p-3 rounded-2xl border bg-white">
              <div className="font-medium mb-1">Ferramentas</div>
              <div className="flex flex-wrap gap-2">
                <button onClick={exportCSV} className="px-3 py-2 rounded-lg bg-gray-100 border">Exportar CSV</button>
                <button onClick={printReport} className="px-3 py-2 rounded-lg bg-gray-100 border">Imprimir (PDF)</button>
              </div>
              <div className="text-xs text-gray-500 mt-2">CSV inclui histórico; use Imprimir→Salvar como PDF para relatório completo.</div>
            </div>
          </section>
        )}

        {tab==="simulate" && (
          <section className="space-y-3">
            <h2 className="text-lg font-semibold">Simulação de Personas</h2>
            <div className="p-3 rounded-2xl border bg-white text-sm overflow-auto">
              <table className="min-w-full">
                <thead><tr className="text-left text-xs text-gray-600"><th className="p-2">Persona</th><th className="p-2">Cobertura</th><th className="p-2">Acurácia antes</th><th className="p-2">Acurácia depois</th></tr></thead>
                <tbody>
                  {PERSONAS.map((p,i)=> (
                    <tr key={i} className="odd:bg-white even:bg-gray-50">
                      <td className="p-2">{p.nome} <span className="text-xs text-gray-500">({p.comportamento})</span></td>
                      <td className="p-2">{p.cobertura}%</td>
                      <td className="p-2">{p.acuraciaAntes}%</td>
                      <td className="p-2">{p.acuraciaDepois}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="p-3 rounded-2xl border bg-white">
              <div className="font-medium mb-1">Exemplos de conversas traduzidas (simulado)</div>
              {PERSONAS.map((p,i)=> (
                <div key={i} className="text-sm py-2 border-t first:border-t-0">
                  <div className="font-medium">{p.nome}</div>
                  {p.conversa.map((f,j)=> (
                    <div key={j} className="grid grid-cols-1 sm:grid-cols-2 gap-2"><div className="text-gray-600">Usuário: “{f}”</div><div className="font-medium">Tradução: “{traducaoSimulada(p.nome,f)}”</div></div>
                  ))}
                </div>
              ))}
            </div>
          </section>
        )}
      </main>

      <footer className="max-w-4xl mx-auto px-4 pb-10 text-center text-xs text-gray-500">
        Protótipo — Requer internet — Use apenas com supervisão clínica quando aplicável.
      </footer>
    </div>
  );
}
